"""
Extra novelty mining #1: does each metal's contribution to predicted MetS
risk depend on age, sex, or BMI (effect modification), using SHAP
interaction values from the already-fitted CatBoost model. Reuses
shared_state.joblib -- no refitting needed.
"""
import numpy as np
import pandas as pd
import joblib
import shap
from scipy.stats import spearmanr
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

METALS = {
    "LBXBPB": "Blood lead", "LBXBCD": "Blood cadmium", "LBXTHG": "Blood mercury",
    "LBXBSE": "Blood selenium", "LBXBMN": "Blood manganese",
}
MODIFIERS = {"RIDAGEYR": "Age", "sex_female": "Sex (female)", "BMXBMI": "BMI"}


def main():
    state = joblib.load("shared_state.joblib")
    cb_model = state["cb_model"]
    Xt_test_df = state["Xt_test_df"]
    feat_names = list(Xt_test_df.columns)

    explainer = shap.TreeExplainer(cb_model)
    iv = explainer.shap_interaction_values(Xt_test_df)
    print("Interaction tensor:", iv.shape)

    idx = {**{m: feat_names.index(m) for m in METALS}, **{m: feat_names.index(m) for m in MODIFIERS}}

    rows = []
    for metal_key, metal_label in METALS.items():
        for mod_key, mod_label in MODIFIERS.items():
            inter = iv[:, idx[metal_key], idx[mod_key]] * 2
            mod_val = Xt_test_df[mod_key].values
            rho, p = spearmanr(mod_val, inter)
            rows.append({
                "metal": metal_label, "modifier": mod_label,
                "mean_abs_interaction": float(np.mean(np.abs(inter))),
                "spearman_rho": round(rho, 4), "spearman_p": p,
            })
    table = pd.DataFrame(rows).sort_values("mean_abs_interaction", ascending=False)
    n_tests = len(table)
    table["bonferroni_alpha"] = 0.05 / n_tests
    table["significant_after_bonferroni"] = table["spearman_p"] < table["bonferroni_alpha"]
    table.to_csv("table_metal_demographic_interaction.csv", index=False)
    pd.set_option("display.width", 120)
    print(table.to_string(index=False))

    # Heatmap: metals x {age, sex, BMI}
    mat = table.pivot(index="metal", columns="modifier", values="mean_abs_interaction")
    mat = mat.loc[list(METALS.values()), list(MODIFIERS.values())]
    fig, ax = plt.subplots(figsize=(6, 5))
    im = ax.imshow(mat.values, cmap="Greens")
    ax.set_xticks(range(len(mat.columns))); ax.set_xticklabels(mat.columns)
    ax.set_yticks(range(len(mat.index))); ax.set_yticklabels(mat.index)
    for i in range(mat.shape[0]):
        for j in range(mat.shape[1]):
            ax.text(j, i, f"{mat.values[i,j]:.4f}", ha="center", va="center", fontsize=9)
    fig.colorbar(im, label="Mean |SHAP interaction|")
    ax.set_title("Effect modification: does each metal's contribution\ndepend on age, sex, or BMI?", fontsize=10.5)
    fig.tight_layout()
    fig.savefig("fig_metal_demographic_interaction.png", dpi=200)
    print("Saved fig_metal_demographic_interaction.png")

    # Highlight the most STATISTICALLY significant hit (not just largest raw
    # magnitude -- manganese x age turns out to be far more significant than
    # lead x age despite a smaller mean |interaction|)
    top = table.sort_values("spearman_p").iloc[0]
    metal_key = [k for k, v in METALS.items() if v == top["metal"]][0]
    mod_key = [k for k, v in MODIFIERS.items() if v == top["modifier"]][0]
    inter = iv[:, idx[metal_key], idx[mod_key]] * 2
    metal_val = Xt_test_df[metal_key].values
    mod_val = Xt_test_df[mod_key].values
    fig2, ax2 = plt.subplots(figsize=(6, 4.5))
    sc = ax2.scatter(metal_val, inter, c=mod_val, cmap="viridis", s=14, alpha=0.7)
    ax2.axhline(0, color="gray", lw=1)
    ax2.set_xlabel(f"{top['metal']} (standardized)")
    ax2.set_ylabel(f"SHAP interaction: {top['metal']} x {top['modifier']}")
    fig2.colorbar(sc, ax=ax2, label=top["modifier"])
    ax2.set_title(f"Strongest effect-modification hit: {top['metal']} x {top['modifier']}\n"
                   f"(rho={top['spearman_rho']}, p={top['spearman_p']:.2e})", fontsize=10)
    fig2.tight_layout()
    fig2.savefig("fig_top_effect_modification.png", dpi=200)
    print("Saved fig_top_effect_modification.png")


if __name__ == "__main__":
    main()
