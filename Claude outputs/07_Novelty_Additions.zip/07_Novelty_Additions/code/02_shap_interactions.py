"""
Addition 2: test the toxic-essential metal antagonism hypothesis (selenium
protecting against cadmium/lead toxicity) using SHAP interaction values
from the fitted CatBoost model, computed on the full held-out test
partition (n=2,229) for consistency with Figures 3-5 of the manuscript.
"""
import numpy as np
import pandas as pd
import joblib
import shap
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

METALS = {
    "LBXBPB": "Blood lead",
    "LBXBCD": "Blood cadmium",
    "LBXTHG": "Blood mercury",
    "LBXBSE": "Blood selenium",
    "LBXBMN": "Blood manganese",
}


def main():
    state = joblib.load("shared_state.joblib")
    cb_model = state["cb_model"]
    Xt_test_df = state["Xt_test_df"]
    test_df = state["test_df"].reset_index(drop=True)

    explainer = shap.TreeExplainer(cb_model)
    interaction_values = explainer.shap_interaction_values(Xt_test_df)
    print("Interaction tensor shape:", interaction_values.shape)

    feat_names = list(Xt_test_df.columns)
    idx = {name: feat_names.index(name) for name in METALS}

    # Mean |interaction| across all test rows, off-diagonal only, for every metal pair
    mean_abs_interaction = np.mean(np.abs(interaction_values), axis=0)  # (46, 46)
    metal_cols = list(METALS.keys())
    metal_idx = [idx[m] for m in metal_cols]
    submatrix = mean_abs_interaction[np.ix_(metal_idx, metal_idx)]
    pair_rows = []
    for i, m1 in enumerate(metal_cols):
        for j, m2 in enumerate(metal_cols):
            if j <= i:
                continue
            pair_rows.append({
                "metal_1": METALS[m1], "metal_2": METALS[m2],
                "mean_abs_shap_interaction": submatrix[i, j] * 2,  # SHAP splits interaction across the pair symmetrically; report the combined (Lundberg convention: value at [i,j] and [j,i] are equal, each already half the joint contribution)
            })
    pair_table = pd.DataFrame(pair_rows).sort_values("mean_abs_shap_interaction", ascending=False)
    pair_table.to_csv("table_metal_interaction_ranking.csv", index=False)
    print(pair_table.to_string(index=False))

    # Heatmap of the 5x5 metal-metal interaction matrix
    fig, ax = plt.subplots(figsize=(5.5, 5))
    labels = [METALS[m] for m in metal_cols]
    disp = submatrix.copy()
    np.fill_diagonal(disp, np.nan)
    im = ax.imshow(disp, cmap="Oranges")
    ax.set_xticks(range(len(labels))); ax.set_xticklabels(labels, rotation=45, ha="right")
    ax.set_yticks(range(len(labels))); ax.set_yticklabels(labels)
    for i in range(len(labels)):
        for j in range(len(labels)):
            if i != j:
                ax.text(j, i, f"{submatrix[i,j]:.4f}", ha="center", va="center", fontsize=8)
    fig.colorbar(im, label="Mean |SHAP interaction|")
    ax.set_title("Pairwise SHAP interaction strength among the 5 blood metals\n(CatBoost, held-out test partition, n=2,229)", fontsize=10)
    fig.tight_layout()
    fig.savefig("fig_metal_interaction_heatmap.png", dpi=200)
    print("Saved fig_metal_interaction_heatmap.png")

    # Dependence-style plots: selenium's SHAP contribution colored by cadmium, and by lead
    se_shap_main = interaction_values[:, idx["LBXBSE"], idx["LBXBSE"]]  # Se's own main effect
    se_val = Xt_test_df["LBXBSE"].values
    cd_val = Xt_test_df["LBXBCD"].values
    pb_val = Xt_test_df["LBXBPB"].values

    fig2, axes = plt.subplots(1, 2, figsize=(11, 4.3))
    for ax, other_val, other_name in zip(axes, [cd_val, pb_val], ["cadmium", "lead"]):
        # interaction component specifically: Se x other metal
        other_key = "LBXBCD" if other_name == "cadmium" else "LBXBPB"
        se_other_interaction = interaction_values[:, idx["LBXBSE"], idx[other_key]] * 2
        sc = ax.scatter(se_val, se_other_interaction, c=other_val, cmap="coolwarm", s=14, alpha=0.7)
        ax.axhline(0, color="gray", lw=1)
        ax.set_xlabel("Selenium (standardized, imputed)")
        ax.set_ylabel(f"SHAP interaction: selenium × {other_name}")
        ax.set_title(f"Selenium × {other_name.capitalize()} interaction", fontsize=10)
        fig2.colorbar(sc, ax=ax, label=f"{other_name.capitalize()} (standardized)")
    fig2.suptitle("Testing the toxic-essential antagonism hypothesis: does selenium's contribution\n"
                  "to predicted MetS risk depend on cadmium/lead level?", fontsize=11)
    fig2.tight_layout(rect=[0, 0, 1, 0.90])
    fig2.savefig("fig_selenium_interaction_dependence.png", dpi=200)
    print("Saved fig_selenium_interaction_dependence.png")

    # Simple correlation summary: does the Se x metal interaction term vary
    # systematically with the other metal's level? (Spearman rho)
    from scipy.stats import spearmanr
    rows = []
    for other_name, other_key, other_val in [("cadmium", "LBXBCD", cd_val), ("lead", "LBXBPB", pb_val)]:
        se_other_interaction = interaction_values[:, idx["LBXBSE"], idx[other_key]] * 2
        rho, p = spearmanr(other_val, se_other_interaction)
        rows.append({
            "pair": f"selenium x {other_name}",
            "mean_abs_interaction": float(np.mean(np.abs(se_other_interaction))),
            "spearman_rho_interaction_vs_other_metal_level": round(rho, 4),
            "spearman_p": p,
        })
    pd.DataFrame(rows).to_csv("table_selenium_antagonism_test.csv", index=False)
    print(pd.DataFrame(rows).to_string(index=False))


if __name__ == "__main__":
    main()
